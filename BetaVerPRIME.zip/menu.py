import os
import sys
import select

from settings import settings

def check_esc():
    dr,_,_ = select.select([sys.stdin], [], [], 0)
    if dr:
        key = sys.stdin.read(1)
        if key == '\x1b':
            return True
    return False


def print_menu():
    os.system("clear")
    print("""
╔══════════════════════════════════╗
║        ⚡     PRIME     ⚡       ║
╠══════════════════════════════════╣
║ 1) Start generování              ║
║ 2) Stop generování               ║
║ 3) Reset                         ║
║ 4) Velká prvočísla               ║
║ 5) Nastavení                     ║
║ 6) Matrix Rain                   ║
║ 7) Exit                          ║
╚══════════════════════════════════╝
(ESC zastaví Matrix Rain a PrimeGen)
""")


def settings_menu():
    while True:
        os.system("clear")
        print(f"""
╔══════════════════════════════════╗
║            ⚙ SETTINGS ⚙          ║
╠══════════════════════════════════╣
║ Limit zapnut: {settings.limit_enabled}
║ Limit číslo: {settings.limit_number}
║ Auto-save: {settings.auto_save}
║ Soubor: {settings.save_file}
║ Matrix speed: {settings.matrix_speed}
╠══════════════════════════════════╣
║ 1) Přepnout limit                ║
║ 2) Nastavit limit                ║
║ 3) Přepnout auto-save            ║
║ 4) Změnit název souboru          ║
║ 5) Nastavit matrix speed         ║
║ 6) Zpět                          ║
╚══════════════════════════════════╝
""")

        c = input("Vyber → ")
        if c=="1": settings.limit_enabled = not settings.limit_enabled
        elif c=="2":
            try: settings.limit_number = int(input("Nový limit: "))
            except: pass
        elif c=="3": settings.auto_save = not settings.auto_save
        elif c=="4": settings.save_file = input("Nový název: ")
        elif c=="5":
            try: settings.matrix_speed = float(input("Nová rychlost (0.01-0.2): "))
            except: pass
        elif c=="6": break
