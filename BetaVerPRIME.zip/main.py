import sys
import tty, termios

from intro import run_intro
from generator import PrimeGenerator
from matrix import start_matrix
from menu import print_menu, settings_menu
from velkacisla import je_prvocislo

def main():
    run_intro()  # spustí pygame intro

    gen = PrimeGenerator()
    gen.daemon = True
    gen.start()

    while True:
        print_menu()
        choice = input("Vyber → ")

        if choice=="1":
            gen.start_gen()
        elif choice=="2":
            gen.stop_gen()
        elif choice=="3":
            gen.reset_gen()
        elif choice=="4":
            je_prvocislo(x)
        elif choice=="5":
            settings_menu()
        elif choice=="6":
            start_matrix()
        elif choice=="7":
            print("Bye bro")
            sys.exit()


if __name__ == "__main__":
    fd = sys.stdin.fileno()
    old = termios.tcgetattr(fd)
    tty.setcbreak(fd)
    try:
        main()
    finally:
        termios.tcsetattr(fd, termios.TCSADRAIN, old)
