import threading
import time
import os
import random

from settings import settings
from menu import check_esc

stop_all = False

class MatrixRain(threading.Thread):
    def __init__(self):
        super().__init__()
        self.running = False

    def run(self):
        global stop_all
        columns = os.get_terminal_size().columns
        chars = "1234567890!@#$%^&*()qwertyuiopasdfghjklzxcvbnm"

        while True:
            if stop_all or not self.running:
                time.sleep(0.01)
                continue

            line = "".join(random.choice(chars) for _ in range(columns))
            print("\033[92m" + line + "\033[0m", end="")
            time.sleep(settings.matrix_speed)

def start_matrix():
    global stop_all
    stop_all = False
    rain = MatrixRain()
    rain.running = True
    rain.daemon = True
    rain.start()

    print("Matrix Rain běží... (ESC pro stop)")
    while True:
        if check_esc():
            rain.running = False
            break
        time.sleep(0.01)
